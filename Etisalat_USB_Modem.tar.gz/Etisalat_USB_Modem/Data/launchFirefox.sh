#!/bin/bash

firefox $@
