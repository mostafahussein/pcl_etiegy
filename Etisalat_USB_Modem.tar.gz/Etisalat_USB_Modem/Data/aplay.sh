#!/bin/bash

aplay $@
