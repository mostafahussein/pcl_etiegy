#!/bin/bash
evince $@ 
